# Conversation-engine-for-deaf-and-dumb-people
AI model that recognize the hand symbols through camera and predict the sign.
